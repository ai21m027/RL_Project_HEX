#!/bin/sh

sbatch start_generators.sh
sbatch start_trainer.sh