# Required packages
- pytorch


A test setup is included showing how to load and use the AI in human_vs_machine.py
